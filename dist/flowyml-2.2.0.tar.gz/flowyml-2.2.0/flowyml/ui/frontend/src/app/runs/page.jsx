import React, { useEffect, useState } from 'react';
import { fetchApi } from '../../utils/api';
import { Link, useSearchParams, useNavigate } from 'react-router-dom';
import { PlayCircle, Clock, CheckCircle, XCircle, Activity, ArrowRight, Calendar, Filter, RefreshCw, Layout, GitCompare, CheckSquare, X } from 'lucide-react';
import { Card } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';
import { Button } from '../../components/ui/Button';
import { format } from 'date-fns';
import { DataView } from '../../components/ui/DataView';
import { StatusBadge } from '../../components/ui/ExecutionStatus';
import { useProject } from '../../contexts/ProjectContext';
import { NavigationTree } from '../../components/NavigationTree';
import { RunDetailsPanel } from '../../components/RunDetailsPanel';

export function Runs() {
    const [runs, setRuns] = useState([]);
    const [loading, setLoading] = useState(true);
    const [selectedRun, setSelectedRun] = useState(null);
    const [searchParams] = useSearchParams();
    const navigate = useNavigate();
    const { selectedProject } = useProject();

    // Selection & Comparison State
    const [selectionMode, setSelectionMode] = useState('single');
    const [selectedRunIds, setSelectedRunIds] = useState([]);


    // Filter states
    const [statusFilter, setStatusFilter] = useState('all');
    const pipelineFilter = searchParams.get('pipeline');

    const fetchRuns = async () => {
        setLoading(true);
        try {
            let url = '/api/runs/?limit=100';
            if (selectedProject) {
                url += `&project=${encodeURIComponent(selectedProject)}`;
            }
            if (pipelineFilter) {
                url += `&pipeline=${encodeURIComponent(pipelineFilter)}`;
            }

            const res = await fetchApi(url);
            const data = await res.json();
            setRuns(data.runs || []);
        } catch (err) {
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchRuns();
    }, [selectedProject, pipelineFilter]);

    const handleRunSelect = (run) => {
        if (selectionMode === 'single') {
            setSelectedRun(run);
        }
    };

    const toggleSelectionMode = () => {
        if (selectionMode === 'single') {
            setSelectionMode('multi');
            setSelectedRunIds([]);
        } else {
            setSelectionMode('single');
            setSelectedRunIds([]);
        }
    };

    const handleMultiSelect = (runId, checked) => {
        if (checked) {
            setSelectedRunIds(prev => [...prev, runId]);
        } else {
            setSelectedRunIds(prev => prev.filter(id => id !== runId));
        }
    };

    const handleCompare = () => {
        if (selectedRunIds.length >= 2) {
            navigate(`/compare?runs=${selectedRunIds.join(',')}`);
        }
    };

    return (
        <div className="h-screen flex flex-col overflow-hidden bg-slate-50 dark:bg-slate-900">
            {/* Header */}
            <div className="bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 px-6 py-4 shrink-0">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 max-w-[1800px] mx-auto">
                    <div>
                        <h1 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                            <PlayCircle className="text-blue-500" />
                            Pipeline Runs
                        </h1>
                        <p className="text-sm text-slate-600 dark:text-slate-400">
                            Monitor and track all your pipeline executions
                        </p>
                    </div>
                    <div className="flex items-center gap-3">
                        {selectionMode === 'multi' ? (
                            <>
                                <span className="text-sm text-slate-500 mr-2">
                                    {selectedRunIds.length} selected
                                </span>
                                <Button
                                    size="sm"
                                    variant="primary"
                                    disabled={selectedRunIds.length < 2}
                                    onClick={handleCompare}
                                >
                                    <GitCompare size={16} className="mr-2" />
                                    Compare
                                </Button>
                                <Button variant="ghost" size="sm" onClick={toggleSelectionMode}>
                                    <X size={16} className="mr-2" />
                                    Cancel
                                </Button>
                            </>
                        ) : (
                            <Button variant="outline" size="sm" onClick={toggleSelectionMode}>
                                <CheckSquare size={16} className="mr-2" />
                                Select to Compare
                            </Button>
                        )}

                        <Button variant="outline" size="sm" onClick={fetchRuns} disabled={loading}>
                            <RefreshCw size={16} className={`mr-2 ${loading ? 'animate-spin' : ''}`} />
                            Refresh
                        </Button>
                    </div>
                </div>
            </div>

            {/* Main Content */}
            <div className="flex-1 overflow-hidden">
                <div className="h-full max-w-[1800px] mx-auto px-6 py-6">
                    <div className="h-full flex flex-col md:flex-row gap-4 md:gap-6">
                        {/* Left Sidebar - Navigation */}
                        <div className="w-full md:w-[320px] shrink-0 flex flex-col bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 overflow-hidden shadow-sm h-[280px] md:h-auto">
                            <div className="p-3 border-b border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/50 flex justify-between items-center">
                                <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Explorer</h3>
                                {pipelineFilter && (
                                    <Badge variant="secondary" className="text-[10px]">
                                        Filtered: {pipelineFilter}
                                    </Badge>
                                )}
                            </div>
                            <div className="flex-1 min-h-0">
                                <NavigationTree
                                    mode="runs"
                                    projectId={selectedProject}
                                    onSelect={handleRunSelect}
                                    selectedId={selectedRun?.run_id}
                                    selectionMode={selectionMode}
                                    selectedIds={selectedRunIds}
                                    onMultiSelect={handleMultiSelect}
                                />
                            </div>
                        </div>

                        {/* Right Content - Details Panel or Empty State */}
                        <div className="flex-1 min-w-0 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 overflow-hidden shadow-sm">
                            {selectedRun ? (
                                <RunDetailsPanel
                                    run={selectedRun}
                                    onClose={() => setSelectedRun(null)}
                                />
                            ) : (
                                <div className="h-full flex flex-col items-center justify-center text-center p-8 bg-slate-50/50 dark:bg-slate-900/50">
                                    <div className="w-20 h-20 bg-gradient-to-br from-blue-100 to-blue-200 dark:from-blue-900/30 dark:to-blue-800/30 rounded-full flex items-center justify-center mb-6">
                                        <PlayCircle size={40} className="text-blue-500" />
                                    </div>
                                    <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">
                                        Select a Run
                                    </h2>
                                    <p className="text-slate-500 max-w-md mb-6">
                                        Choose a run from the sidebar to view execution details, logs, and artifacts.
                                    </p>
                                    <div className="bg-slate-900 dark:bg-slate-950 rounded-lg p-4 max-w-md mx-auto text-left shadow-lg">
                                        <p className="text-xs text-slate-400 mb-2">Run a pipeline from the CLI:</p>
                                        <pre className="text-sm font-mono text-slate-300 overflow-x-auto">
                                            <code>{`flowyml run my_pipeline`}</code>
                                        </pre>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
