"""Plugin System for Custom Stack Components.

This module provides a robust plugin system that allows users to:
1. Discover and install plugins from various sources (PyPI, Local)
2. Manage plugin lifecycles (install, update, remove)
3. Auto-discover components via entry points
4. Seamlessly integrate components from other ecosystems via Generic Bridges
"""

import importlib
import importlib.util
import importlib.metadata
import inspect
import subprocess
import sys
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

from loguru import logger

from flowyml.stacks.components import (
    StackComponent,
    Orchestrator,
    ArtifactStore,
    ContainerRegistry,
    ComponentType,
)
from flowyml.stacks.bridge import GenericBridge, AdaptationRule


# Lazy import to avoid circular dependencies
def _get_zenml_bridge():
    """Lazy import of ZenMLBridge to avoid import errors when ZenML is not installed."""
    from flowyml.stacks.zenml_bridge import ZenMLBridge

    return ZenMLBridge()


@dataclass
class PluginInfo:
    """Metadata about a plugin."""

    name: str
    version: str
    description: str = ""
    author: str = ""
    is_installed: bool = False
    source: str = "pypi"  # "pypi", "local", "github"
    dependencies: list[str] = field(default_factory=list)
    components: list[str] = field(default_factory=list)


@runtime_checkable
class PluginBridge(Protocol):
    """Protocol for plugin bridges that adapt external components."""

    def wrap_component(
        self,
        component_class: Any,
        name: str,
        config: dict[str, Any] | None = None,
    ) -> type[StackComponent]:
        """Wrap an external component class into a flowyml component."""
        ...

    def is_available(self) -> bool:
        """Check if the external system is available."""
        ...


class ComponentRegistry:
    """Registry for stack component plugins.

    Supports:
    - Auto-discovery via entry points
    - Manual registration
    - Generic Bridge system for external integrations
    - Plugin management (install/uninstall)
    """

    def __init__(self):
        self._orchestrators: dict[str, type[Orchestrator]] = {}
        self._artifact_stores: dict[str, type[ArtifactStore]] = {}
        self._container_registries: dict[str, type[ContainerRegistry]] = {}
        self._model_deployers: dict[str, type[Any]] = {}
        self._model_registries: dict[str, type[Any]] = {}
        self._custom_components: dict[str, type[StackComponent]] = {}
        self._plugins: dict[str, PluginInfo] = {}
        self._bridges: dict[str, PluginBridge] = {}

        # Register default generic bridge
        self._register_default_bridges()

        # Auto-discover plugins
        self._discover_installed_plugins()

    def _register_builtin_components(self) -> None:
        """Register first-party serving flavors so a fresh registry is complete.

        Model deployers (local Docker / Kubernetes / OpenShift) and model
        registries (MLflow / Azure ML / Vertex / SageMaker) are registered via
        ``@register_component`` decorators that only fire on first import.
        Because the global registry can be reset (e.g. in tests), we (re-)apply
        the built-in flavors explicitly here so they resolve regardless of the
        module import cache — mirroring ZenML's built-in flavor registration.

        Imports are light-weight: heavy cloud SDKs are only imported when a
        component is actually *initialized*, never at class-definition time.
        """
        import contextlib

        with contextlib.suppress(Exception):
            from flowyml.deployment.targets import (
                KubernetesDeployer,
                LocalDockerDeployer,
                OpenShiftDeployer,
            )

            self.register(LocalDockerDeployer, "local_docker")
            self.register(KubernetesDeployer, "kubernetes")
            self.register(OpenShiftDeployer, "openshift")

        with contextlib.suppress(Exception):
            from flowyml.plugins.model_registries import (
                AzureMLModelRegistry,
                MLflowModelRegistry,
                SageMakerModelRegistry,
                VertexModelRegistry,
            )

            self.register(MLflowModelRegistry, "mlflow_registry")
            self.register(AzureMLModelRegistry, "azureml_registry")
            self.register(VertexModelRegistry, "vertex_model_registry")
            self.register(SageMakerModelRegistry, "sagemaker_model_registry")

        with contextlib.suppress(Exception):
            from flowyml.plugins.deployers import (
                GCPCloudRunDeployer,
                SageMakerEndpointDeployer,
                VertexEndpointDeployer,
            )

            self.register(VertexEndpointDeployer, "vertex_endpoint")
            self.register(SageMakerEndpointDeployer, "sagemaker_endpoint")
            self.register(GCPCloudRunDeployer, "gcp_cloud_run")

    def _register_default_bridges(self) -> None:
        """Register default bridges."""
        # Register a generic bridge that can handle ZenML components via rules
        zenml_rules = [
            AdaptationRule(
                source_type="zenml.orchestrators.base.BaseOrchestrator",
                target_type=ComponentType.ORCHESTRATOR,
                method_mapping={"run_pipeline": "run"},
            ),
            AdaptationRule(
                source_type="zenml.artifact_stores.base_artifact_store.BaseArtifactStore",
                target_type=ComponentType.ARTIFACT_STORE,
            ),
            AdaptationRule(
                source_type="zenml.container_registries.base_container_registry.BaseContainerRegistry",
                target_type=ComponentType.CONTAINER_REGISTRY,
            ),
            # Fallback rule for anything named *Orchestrator
            AdaptationRule(
                name_pattern=".*Orchestrator",
                target_type=ComponentType.ORCHESTRATOR,
            ),
        ]
        self.register_bridge("zenml", GenericBridge(rules=zenml_rules))

        # We can add other default bridges here (e.g. Airflow) without hard deps

    def register_bridge(self, prefix: str, bridge: PluginBridge) -> None:
        """Register a bridge for a specific URI prefix (e.g., 'zenml:', 'airflow:')."""
        self._bridges[prefix] = bridge

    def _discover_installed_plugins(self) -> None:
        """Auto-discover installed plugins via entry points."""
        try:
            # Discover flowyml plugins
            eps = importlib.metadata.entry_points()
            if hasattr(eps, "select"):
                flowyml_eps = eps.select(group="flowyml.stack_components")
            else:
                flowyml_eps = eps.get("flowyml.stack_components", [])

            for ep in flowyml_eps:
                try:
                    component_class = ep.load()
                    self.register(component_class)

                    # Record plugin info
                    dist = importlib.metadata.distribution(ep.dist.name)
                    self._plugins[ep.dist.name] = PluginInfo(
                        name=ep.dist.name,
                        version=dist.version,
                        description=dist.metadata.get("Summary", ""),
                        author=dist.metadata.get("Author", ""),
                        is_installed=True,
                        source="pypi",
                        components=[ep.name],
                    )
                except Exception:
                    pass

            # Discover Bridges
            if hasattr(eps, "select"):
                bridge_eps = eps.select(group="flowyml.bridges")
            else:
                bridge_eps = eps.get("flowyml.bridges", [])

            for ep in bridge_eps:
                try:
                    bridge_class = ep.load()
                    self.register_bridge(ep.name, bridge_class())
                except Exception:
                    pass

        except Exception:
            # Entry points not available or error in discovery
            pass

    def register(self, component_class: type[StackComponent], name: str | None = None) -> None:
        """Register a stack component.

        Args:
            component_class: Component class to register
            name: Optional name override. If None, uses class name in snake_case
        """
        if name is None:
            name = self._class_to_snake_case(component_class.__name__)

        # Determine component type and register.  Model deployers and model
        # registries are first-class component types (mirroring ZenML's
        # ``BaseModelDeployer`` / ``BaseModelRegistry`` flavors), so they get
        # dedicated buckets *and* remain reachable via ``get_component`` for
        # backward compatibility.
        if issubclass(component_class, Orchestrator):
            self._orchestrators[name] = component_class
        elif issubclass(component_class, ArtifactStore):
            self._artifact_stores[name] = component_class
        elif issubclass(component_class, ContainerRegistry):
            self._container_registries[name] = component_class
        elif self._is_model_deployer(component_class):
            self._model_deployers[name] = component_class
        elif self._is_model_registry(component_class):
            self._model_registries[name] = component_class
        else:
            self._custom_components[name] = component_class

    @staticmethod
    def _is_model_deployer(component_class: type) -> bool:
        """Return True if *component_class* is a model deployer flavor.

        Recognizes both the deployment-layer ``BaseDeployer`` (a
        ``StackComponent``) and the plugin-layer ``ModelDeployerPlugin``.
        Imports are performed lazily to avoid import cycles.
        """
        for module_path, attr in (
            ("flowyml.deployment.base", "BaseDeployer"),
            ("flowyml.plugins.base", "ModelDeployerPlugin"),
        ):
            try:
                module = importlib.import_module(module_path)
                base = getattr(module, attr)
                if isinstance(component_class, type) and issubclass(component_class, base):
                    return True
            except Exception:
                continue
        return False

    @staticmethod
    def _is_model_registry(component_class: type) -> bool:
        """Return True if *component_class* is a model registry flavor.

        Recognizes the plugin-layer ``ModelRegistryPlugin``.  Imports are
        performed lazily to avoid import cycles.
        """
        try:
            from flowyml.plugins.base import ModelRegistryPlugin

            return isinstance(component_class, type) and issubclass(
                component_class,
                ModelRegistryPlugin,
            )
        except Exception:
            return False

    def get_orchestrator(self, name: str) -> type[Orchestrator] | None:
        """Get orchestrator class by name."""
        return self._orchestrators.get(name)

    def get_artifact_store(self, name: str) -> type[ArtifactStore] | None:
        """Get artifact store class by name."""
        return self._artifact_stores.get(name)

    def get_container_registry(self, name: str) -> type[ContainerRegistry] | None:
        """Get container registry class by name."""
        return self._container_registries.get(name)

    def get_model_deployer(self, name: str) -> type[Any] | None:
        """Get a model deployer class by its flavor name (e.g. ``openshift``)."""
        return self._model_deployers.get(name) or self._custom_components.get(name)

    def get_model_registry(self, name: str) -> type[Any] | None:
        """Get a model registry class by its flavor name (e.g. ``azureml_registry``)."""
        return self._model_registries.get(name) or self._custom_components.get(name)

    def get_component(self, name: str) -> type[StackComponent] | None:
        """Get any component by name."""
        return (
            self._orchestrators.get(name)
            or self._artifact_stores.get(name)
            or self._container_registries.get(name)
            or self._model_deployers.get(name)
            or self._model_registries.get(name)
            or self._custom_components.get(name)
        )

    def list_orchestrators(self) -> list[str]:
        """List all registered orchestrators."""
        return list(self._orchestrators.keys())

    def list_artifact_stores(self) -> list[str]:
        """List all registered artifact stores."""
        return list(self._artifact_stores.keys())

    def list_container_registries(self) -> list[str]:
        """List all registered container registries."""
        return list(self._container_registries.keys())

    def list_model_deployers(self) -> list[str]:
        """List all registered model deployers."""
        return list(self._model_deployers.keys())

    def list_model_registries(self) -> list[str]:
        """List all registered model registries."""
        return list(self._model_registries.keys())

    def list_all(self) -> dict[str, list[str]]:
        """List all registered components."""
        return {
            "orchestrators": self.list_orchestrators(),
            "artifact_stores": self.list_artifact_stores(),
            "container_registries": self.list_container_registries(),
            "model_deployers": self.list_model_deployers(),
            "model_registries": self.list_model_registries(),
            "custom": list(self._custom_components.keys()),
        }

    def list_plugins(self) -> list[PluginInfo]:
        """List all discovered plugins."""
        return list(self._plugins.values())

    def list_bridges(self) -> list[str]:
        """List all registered bridges."""
        return list(self._bridges.keys())

    def load_from_path(self, path: str, class_name: str) -> None:
        """Load a component from a Python file."""
        spec = importlib.util.spec_from_file_location("custom_module", path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Could not load module from {path}")

        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        component_class = getattr(module, class_name)
        self.register(component_class)

    def load_from_module(self, module_path: str) -> None:
        """Load all components from a module."""
        module = importlib.import_module(module_path)

        for _name, obj in inspect.getmembers(module, inspect.isclass):
            if issubclass(obj, StackComponent) and obj != StackComponent:
                self.register(obj)

    def load_via_bridge(
        self,
        bridge_name: str,
        component_path: str,
        name: str | None = None,
    ) -> None:
        """Load a component via a registered bridge."""
        bridge = self._bridges.get(bridge_name)
        if not bridge:
            raise ValueError(
                f"Bridge '{bridge_name}' not found. Available: {list(self._bridges.keys())}",
            )

        module_path, class_name = component_path.rsplit(".", 1)

        try:
            module = importlib.import_module(module_path)
            component_class = getattr(module, class_name)

            wrapper = bridge.wrap_component(component_class, name or class_name)
            self.register(wrapper, name or class_name)
        except ImportError as e:
            raise ImportError(f"Could not import component via {bridge_name}: {e}")

    def load_plugins_from_config(self, config_path: str) -> None:
        """Load plugins from a configuration file."""
        from flowyml.stacks.plugin_config import PluginManager

        manager = PluginManager()
        manager.load_from_yaml(config_path)

        # Get generic bridge (or create one if not exists)
        bridge = self._bridges.get("zenml")  # Use the default generic bridge
        if not bridge or not isinstance(bridge, GenericBridge):
            # Create a fresh generic bridge if needed
            bridge = GenericBridge()
            self.register_bridge("generic", bridge)

        # Register components from config
        for config in manager.configs:
            # Create specific rule for this component
            # Note: In a real implementation, we might want to merge rules or handle them more globally
            # For now, we'll just use the bridge to wrap it

            try:
                # Import the source class
                module_path, class_name = config.source.rsplit(".", 1)
                module = importlib.import_module(module_path)
                component_class = getattr(module, class_name)

                # Create rule from config
                # We need to add this rule to the bridge so it knows how to handle it
                # Or we can pass the rule directly to wrap_component if we modify GenericBridge
                # But GenericBridge uses internal rules.
                # Let's add the rule to the bridge

                # Convert config to rule (simplified)
                target_type = ComponentType.ORCHESTRATOR
                if config.component_type == "artifact_store":
                    target_type = ComponentType.ARTIFACT_STORE
                elif config.component_type == "container_registry":
                    target_type = ComponentType.CONTAINER_REGISTRY

                rule = AdaptationRule(
                    source_type=config.source,
                    target_type=target_type,
                    method_mapping=config.adaptation.get("method_mapping", {}),
                    attribute_mapping=config.adaptation.get("attribute_mapping", {}),
                )

                # Add rule to bridge
                if isinstance(bridge, GenericBridge):
                    bridge.rules.append(rule)

                # Wrap and register
                wrapper = bridge.wrap_component(component_class, config.name)
                self.register(wrapper, config.name)

            except Exception as e:
                print(f"Failed to load plugin {config.name}: {e}")

    def install_plugin(self, package_name: str) -> bool:
        """Install a plugin package via pip.

        The name is validated first: pip would read an argument such as
        ``--index-url=http://...`` as an option rather than a package, letting
        a caller redirect the install at an arbitrary index.
        """
        from flowyml.utils.packages import InvalidPackageNameError, validate_requirement

        try:
            requirement = validate_requirement(package_name)
        except InvalidPackageNameError as exc:
            logger.warning(f"Refusing to install plugin: {exc}")
            return False

        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", requirement])
            # Refresh discovery
            importlib.invalidate_caches()
            self._discover_installed_plugins()
            return True
        except subprocess.CalledProcessError:
            return False

    # ==================== ZenML Integration Methods ====================

    def list_zenml_integrations(self) -> list[str]:
        """List all available ZenML integrations.

        Returns:
            List of integration names (e.g., ['mlflow', 'kubernetes', 'aws']).
        """
        try:
            bridge = _get_zenml_bridge()
            return bridge.list_available_integrations()
        except Exception:
            return []

    def list_installed_zenml_integrations(self) -> list[str]:
        """List installed ZenML integrations.

        Returns:
            List of installed integration names.
        """
        try:
            bridge = _get_zenml_bridge()
            return bridge.list_installed_integrations()
        except Exception:
            return []

    def install_zenml_integration(self, integration_name: str) -> bool:
        """Install a ZenML integration and its dependencies.

        Args:
            integration_name: Name of the integration (e.g., "mlflow", "kubernetes").

        Returns:
            True if installation was successful.

        Example:
            >>> registry = get_component_registry()
            >>> registry.install_zenml_integration("mlflow")
            True
        """
        try:
            bridge = _get_zenml_bridge()
            return bridge.install_integration(integration_name)
        except Exception as e:
            print(f"Failed to install ZenML integration: {e}")
            return False

    def import_zenml_integration(self, integration_name: str) -> list[type[StackComponent]]:
        """Import all components from a ZenML integration.

        This discovers all flavors provided by a ZenML integration and
        registers them as FlowyML components.

        Args:
            integration_name: Name of the integration to import.

        Returns:
            List of wrapped FlowyML component classes.

        Example:
            >>> registry = get_component_registry()
            >>> components = registry.import_zenml_integration("mlflow")
            >>> print([c.__name__ for c in components])
            ['ZenMLMLFlowExperimentTrackerWrapper']
        """
        try:
            bridge = _get_zenml_bridge()
            components = bridge.import_integration(integration_name)

            # Register all imported components
            for component_class in components:
                self.register(component_class)

            return components
        except Exception as e:
            print(f"Failed to import ZenML integration: {e}")
            return []

    def import_all_zenml(self) -> dict[str, list[type[StackComponent]]]:
        """Import all components from all installed ZenML integrations.

        This is the easiest way to make all ZenML components available
        in FlowyML with a single call.

        Returns:
            Dictionary mapping integration names to lists of wrapped components.

        Example:
            >>> registry = get_component_registry()
            >>> all_components = registry.import_all_zenml()
            >>> print(all_components.keys())
            dict_keys(['mlflow', 'kubernetes', 'aws'])
        """
        try:
            bridge = _get_zenml_bridge()
            result = bridge.import_all()

            # Register all imported components
            for _integration_name, components in result.items():
                for component_class in components:
                    self.register(component_class)

            return result
        except Exception as e:
            print(f"Failed to import ZenML integrations: {e}")
            return {}

    @staticmethod
    def _class_to_snake_case(name: str) -> str:
        """Convert ClassName to class_name."""
        import re

        s1 = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", name)
        return re.sub("([a-z0-9])([A-Z])", r"\1_\2", s1).lower()


# Global registry instance
_global_component_registry: ComponentRegistry | None = None

# Durable record of every component registered through ``register_component``.
#
# ``@register_component`` fires exactly once per process, when the defining
# module is first imported.  Python caches modules in ``sys.modules``, so a
# later ``import`` of that module is a no-op and the decorator never runs
# again.  That makes registration by import side effect fragile: if the global
# registry is ever rebuilt (tests reset it, an embedding host re-initializes
# the process, a plugin reload), every component whose module was already
# imported would silently disappear and ``get_component(...)`` would start
# returning ``None`` for the rest of the process.
#
# Recording each ``(class, name)`` pair here and replaying it into every newly
# constructed registry makes registration durable and idempotent, without
# depending on import ordering.  Registrations are keyed by the resolved name
# so a later re-registration of the same name wins, matching the behaviour of
# calling ``ComponentRegistry.register`` directly.
_recorded_components: dict[str, type[StackComponent]] = {}


def _record_component(component_class: type[StackComponent], name: str | None) -> None:
    """Remember a decorator-registered component so registry rebuilds keep it."""
    resolved = name or ComponentRegistry._class_to_snake_case(component_class.__name__)
    _recorded_components[resolved] = component_class


def get_component_registry() -> ComponentRegistry:
    """Get the global component registry."""
    global _global_component_registry
    if _global_component_registry is None:
        # Assign the global *before* registering built-ins so the
        # ``@register_component`` decorators triggered by those imports resolve
        # to this same instance instead of recursively constructing another.
        _global_component_registry = ComponentRegistry()
        _global_component_registry._register_builtin_components()
        # Replay decorator registrations from modules already imported in this
        # process; their decorators will not fire again (see ``_recorded_components``).
        for recorded_name, recorded_cls in _recorded_components.items():
            try:
                _global_component_registry.register(recorded_cls, recorded_name)
            except Exception:  # pragma: no cover - a bad plugin must not break startup
                logger.warning(
                    f"Failed to restore recorded component '{recorded_name}'",
                )
    return _global_component_registry


def reset_component_registry() -> None:
    """Drop the global registry so the next access rebuilds it.

    The rebuilt registry still contains every built-in flavor and every
    component previously registered via ``register_component``, because those
    are replayed from ``_recorded_components``.
    """
    global _global_component_registry
    _global_component_registry = None


def register_component(component_class=None, name: str | None = None):
    """Decorator to register a custom component."""

    def wrapper(cls):
        _record_component(cls, name)
        get_component_registry().register(cls, name)
        return cls

    if component_class is not None:
        _record_component(component_class, name)
        get_component_registry().register(component_class, name)
        return component_class

    return wrapper


def load_component(source: str, name: str | None = None) -> None:
    """Load a component from various sources.

    Args:
        source: Can be:
            - Module path: "my_package.components"
            - File path: "/path/to/component.py:ClassName"
            - Bridge URI: "zenml:zenml.integrations.kubernetes.orchestrators.KubernetesOrchestrator"
            - Bridge URI: "airflow:airflow.providers.google.cloud.operators.bigquery.BigQueryExecuteQueryOperator"
        name: Optional name to register as
    """
    registry = get_component_registry()

    # Check for bridge prefixes (e.g., "zenml:", "airflow:")
    if ":" in source and not source.startswith("/") and not source.startswith("."):
        prefix, path = source.split(":", 1)

        # If prefix is a registered bridge, use it
        if prefix in registry.list_bridges():
            registry.load_via_bridge(prefix, path, name)
            return

        # Special case for file paths that might look like "c:/path" on windows or just "file:Class"
        # But here we assume "file_path:ClassName" for local loading
        if ".py" in prefix:
            registry.load_from_path(prefix, path)
            return

    # Fallback to module load
    registry.load_from_module(source)
